package sol.ser;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.logging.*;
import javax.servlet.*;
import javax.servlet.http.*;
import paw.bd.GestorBD;
import paw.model.*;
import paw.util.UtilesString;

public class FichaArticulo extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String cart = request.getParameter("cart");
        
        
        try {
            if (UtilesString.isVacia(cart)) {
                response.sendRedirect("index.html");
            } else {
                Articulo articulo = new GestorBD().getArticulo(cart);
                if (articulo == null) {
                    request.setAttribute("enlaceSalir", "BuscarArticulos");
                    response.sendError(HttpServletResponse.SC_NOT_FOUND, "El artículo " + cart + " no existe");
                    return;
                } else {
                    //No funciona
                    //String hojeo = request.getRequestURL().append('?').append(request.getQueryString()).toString();
                    //Almacena la ultima pagina en la cabecera Referar, y asi realizar browserback 
                    /*
                    Opcion javascript en el jsp asigandoselo al onclick de el href que contiene hojear
                    <script type="text/javascript">
                        history.forward();
                    </script>
                    
                    */  
                    String hojeo = request.getHeader("referer");
                    request.setAttribute("hojeo", hojeo);
                    request.setAttribute("art", articulo);
                    Boolean admin = request.isUserInRole("administrador");
                    request.setAttribute("admin", admin);
                    RequestDispatcher rd = request.getRequestDispatcher("/fichaArticulo.jsp");
                    rd.forward(request, response);
                }
            }
        } catch (ExcepcionDeAplicacion ex) {
            // Esto no debe hacerse así; lo mejoraremos más adelante !!!
            Logger.getLogger(FichaArticulo.class.getName()).log(Level.SEVERE, null, ex);
            request.setAttribute("enlaceSalir", "index.html");
            throw new ServletException(ex);
        }
    }

}
