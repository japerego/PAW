/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sol.ser;

import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import paw.bd.CriteriosArticulo;
import paw.bd.GestorBD;
import paw.bd.Paginador;
import paw.model.Cliente;
import paw.model.ExcepcionDeAplicacion;
import paw.model.LineaEnRealizacion;
import paw.model.PedidoEnRealizacion;

/**
 *
 * @author javie
 */
public class BuscarArticulos extends HttpServlet {

    private static GestorBD gbd = new GestorBD();
    private static int tamanioPagina = 15;

    @Override
    public void init() throws ServletException {
        super.init();
        try {
            tamanioPagina = Integer.parseInt(this.getInitParameter("tamanioPagina"));
        } catch (Exception ex) {
            Logger.getLogger(BuscarArticulos.class.getName()).log(Level.WARNING, null, ex);
            throw new ServletException(ex);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String tipo = request.getParameter("tipo");
        String precio = request.getParameter("precio");
        String fabricante = request.getParameter("fabricante");
        String nombre = request.getParameter("nombre");
        String codigo = request.getParameter("codigo");  
            try {
                
                CriteriosArticulo ca = new CriteriosArticulo();
                int numPagina;
                ca.setTipo(tipo);
                ca.setFabricante(fabricante);
                ca.setPrecio(precio);
                ca.setNombre(nombre);
                ca.setCodigo(codigo);
                Paginador pagi = gbd.getPaginadorArticulos(ca, tamanioPagina);
                
                String p = request.getParameter("pag");
                try {
                    
                    try{
                        if (!paw.util.UtilesString.isVacia(p)) {
                            numPagina = Integer.parseInt(p);
                            if (numPagina < 1) {
                                numPagina = 1;
                            }
                            if (numPagina > pagi.getNumPaginas()) {
                                numPagina = pagi.getNumPaginas();
                            }
                            
                        } else {
                            numPagina = 1;
                        }
                    }catch(NumberFormatException nfe){
                        numPagina=1;
                    }
                    request.setAttribute("tiposArticulos", gbd.getTiposArticulos());
                    request.setAttribute("fabricantesArticulos", gbd.getFabricantes());
                    request.setAttribute("tipo", ca.getTipo());
                    request.setAttribute("fabricante", ca.getFabricante());
                    request.setAttribute("precio", ca.getPrecio());
                    request.setAttribute("nombre", ca.getNombre());
                    request.setAttribute("codigo", ca.getCodigo());
                    
                    HttpSession session=request.getSession(false);
                    if(session!=null){
        
                        PedidoEnRealizacion carrito=(PedidoEnRealizacion) session.getAttribute("carrito");
                        if(carrito!=null){
                            List<LineaEnRealizacion> lineas = carrito.getLineas();
                            int numart=lineas.size();
                            request.setAttribute("numLin", numart);
                        }
                        else{
                            request.setAttribute("numLin", 0);
                        }      
                    }
                    else{
                        request.setAttribute("numLin", 0);
                    }
                    
                    request.setAttribute("paginador", pagi);
                    request.setAttribute("numRegs", pagi.getNumRegistros());
                    request.setAttribute("numPags", pagi.getNumPaginas());
                    request.setAttribute("pagina", numPagina);
                    request.setAttribute("articulos", gbd.getArticulos(ca , numPagina ,tamanioPagina));
                    
                    
                    //Trabajo 2.12 p5
                    if(pagi.getNumRegistros()==1){
                        response.sendRedirect("FichaArticulo?cart="+gbd.getArticulos(ca , numPagina ,tamanioPagina).get(0).getCodigo());
                        return;
                    }
                    
                    RequestDispatcher rd = request.getRequestDispatcher("/catalogo.jsp");
                    rd.forward(request, response);
                    
                    
                    
                } catch (ExcepcionDeAplicacion ex) {
                    Logger.getLogger(BuscarArticulos.class.getName()).log(Level.SEVERE, null, ex);
                    request.setAttribute("link", "index.html");
                    throw new ServletException(ex);
                }
                
                
            } catch (ExcepcionDeAplicacion ex) {
                Logger.getLogger(BuscarArticulos.class.getName()).log(Level.SEVERE, null, ex);
                request.setAttribute("link", "index.html");
                throw new ServletException(ex);
            }
            
            
        } 
        

    }


