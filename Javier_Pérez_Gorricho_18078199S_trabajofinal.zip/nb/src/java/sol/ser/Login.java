/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sol.ser;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import paw.bd.GestorBD;
import paw.model.ExcepcionDeAplicacion;
import paw.util.UtilesString;
import static paw.util.servlet.UtilesServlet.doForward;

/**
 *
 * @author japerego
 */
public class Login extends HttpServlet {

     GestorBD gbd;

    public void init() throws ServletException {
        super.init();
        gbd = (GestorBD) this.getServletContext().getAttribute("gbd");
        if (gbd == null) {
            gbd = new GestorBD();
            this.getServletContext().setAttribute("gbd", gbd);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.sendRedirect("login.jsp");
        return;
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String nombre=request.getParameter("usr");
        String pwd=request.getParameter("pwd");
         if(UtilesString.isVacia(pwd) || UtilesString.isVacia(nombre)){
            request.setAttribute("error", " Debe introducir datos en todos los campos");
            response.sendRedirect("login.jsp");
        }else{
       
            try {
                if(gbd.comprobarLogin(nombre,pwd)){
                    HttpSession session=request.getSession();
                    session.setAttribute("cliente",gbd.getClienteByUserName(nombre));
                    String retorno =(String) session.getAttribute("retorno");
                    response.sendRedirect(retorno);
                    return;
                }
                else{
                    request.setAttribute("error","Contraseña o usuarios no validos");
                    RequestDispatcher rd = request.getRequestDispatcher("/login.jsp");
                    rd.forward(request, response);
                }
                
            } catch (ExcepcionDeAplicacion ex) {
                Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
            }
         }
        
        
    }

 

}
