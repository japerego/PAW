/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sol.ser;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import paw.bd.GestorBDPedidos;
import paw.model.Cliente;
import paw.model.ExcepcionDeAplicacion;
import paw.model.Pedido;

/**
 *
 * @author javie
 */
public class ConfirmaAnulacion extends HttpServlet {

    GestorBDPedidos gbdp;

    public void init() throws ServletException {
        super.init();
        gbdp = (GestorBDPedidos) this.getServletContext().getAttribute("gbdp");
        if (gbdp == null) {
            gbdp = new GestorBDPedidos();
            this.getServletContext().setAttribute("gbdp", gbdp);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        try {
            String cp = request.getParameter("cp");
            if (cp != null && gbdp.getPedido(cp) != null) {

                Pedido pedi = gbdp.getPedido(cp);
                Cliente cl = (Cliente) session.getAttribute("cliente");
                if (pedi.getCliente().equals(cl)) {
                    if (!pedi.isCursado()) {
                        gbdp.anulaPedido(pedi);
                        
                        response.sendRedirect("PedidosCliente");
                        return;
                    } else {
                        request.setAttribute("enlaceSalir", "../Salir");
                        response.sendError(HttpServletResponse.SC_BAD_REQUEST, "El pedido esta cursado. No puede anularlo");
                        return;
                    }
                } else {
                    request.setAttribute("enlaceSalir", "../Salir");
                    response.sendError(HttpServletResponse.SC_FORBIDDEN, "Usted no esta autorizado para consultar esta informacion");
                    return;
                }
            }
        } catch (ExcepcionDeAplicacion ex) {
            Logger.getLogger(ConfirmaAnulacion.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }
}
