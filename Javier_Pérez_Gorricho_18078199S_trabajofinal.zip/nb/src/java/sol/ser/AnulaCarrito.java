/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sol.ser;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import paw.bd.GestorBDPedidos;
import paw.model.ExcepcionDeAplicacion;
import paw.model.PedidoEnRealizacion;

/**
 *
 * @author javie
 */
public class AnulaCarrito extends HttpServlet {
    
    GestorBDPedidos gbdp;

    public void init() throws ServletException {
        super.init();
        gbdp = (GestorBDPedidos) this.getServletContext().getAttribute("gbdp");
        if (gbdp == null) {
            gbdp = new GestorBDPedidos();
            this.getServletContext().setAttribute("gbdp", gbdp);
        }
    }


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session=request.getSession();
        PedidoEnRealizacion pedACancelar= (PedidoEnRealizacion) session.getAttribute("pedACancelar");
        if(pedACancelar!=null){
            String accion = request.getParameter("accion");
            if(accion.equals("anular")){
                try {
                    gbdp.anulaPedido(pedACancelar);
                    session.removeAttribute("pedACancelar");
                    session.removeAttribute("carrito");
                    response.sendRedirect("AreaCliente");
                    return;
                } catch (ExcepcionDeAplicacion ex) {
                    Logger.getLogger(AnulaCarrito.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            else{
                session.removeAttribute("pedACancelar");
                response.sendRedirect("Carrito");
                return;
            }
        }
        else{
           request.setAttribute("enlaceSalir", "AreaCliente");
           response.sendError(HttpServletResponse.SC_BAD_REQUEST, "La aplicacion no puede determinar el pedido a anular");
           return; 
        }
    }

  
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
    }

}
