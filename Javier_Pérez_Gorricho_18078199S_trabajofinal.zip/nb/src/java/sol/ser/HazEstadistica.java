/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sol.ser;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import paw.bd.GestorBDPedidos;
import paw.model.ExcepcionDeAplicacion;

/**
 *
 * @author javie
 */
@WebServlet(name = "HazEstadistica", urlPatterns = {"/admin/HazEstadistica"})
public class HazEstadistica extends HttpServlet {

         GestorBDPedidos gbdp;

    public void init() throws ServletException {
        super.init();
        gbdp = (GestorBDPedidos) this.getServletContext().getAttribute("gbdp");
        if (gbdp == null) {
            gbdp = new GestorBDPedidos();
            this.getServletContext().setAttribute("gbdp", gbdp);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String anio = request.getParameter("anio");
        String tipo = request.getParameter("tipo");
        String num = request.getParameter("num");
        
        if(paw.util.UtilesString.isVacia(anio) || paw.util.UtilesString.isVacia(num ) || paw.util.UtilesString.isVacia(tipo)){
            RequestDispatcher rd= request.getRequestDispatcher("estadistica.jsp");
            rd.forward(request, response);
        }
        else{
            try {
                int anioent=Integer.parseInt(anio);
                int nument=Integer.parseInt(num);
                String Json=gbdp.getEstadisticaVentasJSON(anioent, tipo, nument);
                request.setAttribute("json", Json);
                request.setAttribute("anio",anio);
                request.setAttribute("tipo",tipo);
                request.setAttribute("num",num );
                RequestDispatcher rd= request.getRequestDispatcher("estadistica.jsp");
                rd.forward(request, response);
            } catch (ExcepcionDeAplicacion ex) {
                Logger.getLogger(BuscarArticulos.class.getName()).log(Level.SEVERE, null, ex);
                request.setAttribute("link", "index.html");
                throw new ServletException(ex);
            }
        }

    }
}
