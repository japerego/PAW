/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sol.ser;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import paw.bd.GestorBDPedidos;
import paw.model.Cliente;
import paw.model.Direccion;
import paw.model.ExcepcionDeAplicacion;
import paw.model.Pedido;
import paw.model.PedidoEnRealizacion;

/**
 *
 * @author javie
 */
public class CierraPedido extends HttpServlet {

    GestorBDPedidos gbdp;

    public void init() throws ServletException {
        super.init();
        gbdp = (GestorBDPedidos) this.getServletContext().getAttribute("gbdp");
        if (gbdp == null) {
            gbdp = new GestorBDPedidos();
            this.getServletContext().setAttribute("gbdp", gbdp);
        }
    }

  

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session=request.getSession();
        PedidoEnRealizacion pedidoEnRealizacion=(PedidoEnRealizacion) session.getAttribute("pedidoACerrar");
        if(pedidoEnRealizacion==null){
             request.setAttribute("enlaceSalir", "AreaCliente");
             response.sendError(HttpServletResponse.SC_BAD_REQUEST, "La aplicacion no puede determinar el pedido a cerrar");
             return;
        }
        else{
            String accion=request.getParameter("accion");
            if(accion.equals("cerrar")){
                try {
                    Cliente cl=(Cliente) session.getAttribute("cliente");
                    Direccion direntrega=cl.getDireccion();
                    Pedido p=gbdp.cierraPedido(pedidoEnRealizacion, direntrega);
                    
                    session.removeAttribute("pedidoACerrar");
                    session.removeAttribute("carrito");
                    
                    response.sendRedirect("VerPedido?cp="+p.getCodigo());
                } catch (ExcepcionDeAplicacion ex) {
                    Logger.getLogger(CierraPedido.class.getName()).log(Level.SEVERE, null, ex);
                }
                
            }
            else{
              
                session.removeAttribute("pedidoACerrar");
                response.sendRedirect("Carrito");
                return;
            }
            
        }
       
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
    }



}
