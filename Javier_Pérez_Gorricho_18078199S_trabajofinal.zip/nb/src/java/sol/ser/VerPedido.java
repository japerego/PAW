/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sol.ser;

import com.google.gson.Gson;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import paw.bd.GestorBD;
import paw.bd.GestorBDPedidos;
import paw.model.Cliente;
import paw.model.ExcepcionDeAplicacion;
import paw.model.Pedido;

/**
 *
 * @author javie
 */
public class VerPedido extends HttpServlet {

    GestorBDPedidos gbdp;

    public void init() throws ServletException {
        super.init();
        gbdp = (GestorBDPedidos) this.getServletContext().getAttribute("gbdp");
        if (gbdp == null) {
            gbdp = new GestorBDPedidos();
            this.getServletContext().setAttribute("gbdp", gbdp);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        Cliente cl = (Cliente) session.getAttribute("cliente");
        String cp = request.getParameter("cp");

        if (cp == null) {
            response.sendRedirect("PedidosCliente");
        } else {
            try {
                Pedido pedido = gbdp.getPedido(cp);

                if (pedido != null && cp.equals(pedido.getCodigo())) {
                    if (cl.equals(pedido.getCliente())) {
                        if(request.getHeader("X-Requested-With")!=null){
                            if ("XMLHttpRequest".equals(request.getHeader("X-Requested-With"))){
                            Gson gson=new Gson();
                            String json=gson.toJson(pedido);
                            response.getWriter().print(json);
                        }
                        }
                        else{
                            request.setAttribute("pedido", pedido);
                            RequestDispatcher rd= request.getRequestDispatcher("verPedido.jsp");
                            rd.forward(request, response);
                        }
                    } else {

                        request.setAttribute("enlaceSalir", "../Salir");
                        response.sendError(HttpServletResponse.SC_FORBIDDEN, "Usted no esta autorizado para consultar esta informacion");
                        return;

                    }
                } else {

                    response.sendError(HttpServletResponse.SC_NOT_FOUND, "Codigo de pedido invalido");
                    return;
                }
            } catch (ExcepcionDeAplicacion ex) {
                Logger.getLogger(VerPedido.class.getName()).log(Level.SEVERE, null, ex);
                request.setAttribute("enlaceSalir", "index.html");
                throw new ServletException(ex);

            }

        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }

}
