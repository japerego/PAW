/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sol.ser;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.mail.MessagingException;
import javax.mail.internet.AddressException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import paw.bd.GestorBD;
import paw.model.Cliente;
import paw.model.ExcepcionDeAplicacion;
import paw.util.ReCaptchaException;
import paw.util.ReCaptchaValidator;
import paw.util.UtilesString;
import paw.util.Validacion;
import paw.util.mail.DatosCorreo;
import paw.util.mail.GestorCorreo;
import paw.util.mail.conf.ConfiguracionCorreo;
import paw.util.servlet.UtilesServlet;

/**
 *
 * @author javie
 */

public class NuevoCliente extends HttpServlet {

    GestorBD gbd;

    public void init() throws ServletException {
        super.init();
        gbd = (GestorBD) this.getServletContext().getAttribute("gbd");
        if (gbd == null) {
            gbd = new GestorBD();
            this.getServletContext().setAttribute("gbd", gbd);
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RequestDispatcher rd = request.getRequestDispatcher("/nuevoCliente.jsp");
        rd.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            HttpServletRequest req = (HttpServletRequest) request;
            request.setCharacterEncoding("UTF-8");
            
            //Supongo que en la declaracion y el casteo de cliente no es necesario poner la ruta
            //entera y simplemente hacerlo en la String de la clase del metodo pplteBean
            paw.model.Cliente cl = (paw.model.Cliente) UtilesServlet.populateBean("paw.model.Cliente", request);
            paw.model.Direccion dir= (paw.model.Direccion) UtilesServlet.populateBean("paw.model.Direccion", request);
            cl.setDireccion(dir);
            String nom = request.getParameter("login");
            String pwd = request.getParameter("pwd");
            String pwd2 = request.getParameter("rpwd");
            
            List<String> errores = new ArrayList<>();
            int privacidadnum = 0;
            try {
                privacidadnum = Integer.parseInt(request.getParameter("privacidad"));
            } catch (NumberFormatException ex) {
                privacidadnum = 0;
            }
            try {
                comprobarCampos(errores, nom, pwd, pwd2, privacidadnum, cl);
                ReCaptchaValidator validca= new ReCaptchaValidator("6Lf_vR4bAAAAAK5A3TKG0URVBT8-lDRPOkTEmEZ4","6Lf_vR4bAAAAAAxFQPh8MQ0jLVoHXtkYcq-JTQjY");
                if(!validca.verifyResponse(req)){
                    errores.add("Valida el captcha");
                }
        
            } catch (ReCaptchaException ex) {
                Logger.getLogger(NuevoCliente.class.getName()).log(Level.SEVERE, null, ex);
            }
            if (errores.isEmpty()) {
                try {
                    Cliente clienteins = gbd.insertaCliente(cl, nom, pwd);
                    HttpSession session = request.getSession();
                    session.setAttribute("cliente", clienteins);
                    try {
                        DatosCorreo mail= new DatosCorreo("japerego@unirioja.es", cl.getEmail() , "Bienvenido a electrosa.com", "Es un placer para nosotros tenerle como cliente. Visite nuestra web en la dirección:\n" +"http://"+ request.getLocalName()+":"+request.getLocalPort() +""+ request.getRequestURL()+"/");
                        mail.setMimeType("text/plain;charset=UTF-8");
                        GestorCorreo.envia(mail, ConfiguracionCorreo.getDefault());
                        
                    } catch (AddressException ex) {
                        Logger.getLogger(NuevoCliente.class.getName()).log(Level.SEVERE, null, ex);
                        response.sendRedirect("clientes/AreaCliente");
                        return;
                    } catch (MessagingException ex) {
                        Logger.getLogger(NuevoCliente.class.getName()).log(Level.SEVERE, null, ex);
                        response.sendRedirect("clientes/AreaCliente");
                        return;
                        
                               
                    }
                    response.sendRedirect("clientes/AreaCliente");
                    return;
                } catch (ExcepcionDeAplicacion ex) {
                    Logger.getLogger(NuevoCliente.class.getName()).log(Level.SEVERE, null, ex);
                }
            } else {
                request.setAttribute("nom", nom);
                request.setAttribute("cliente", cl);
                request.setAttribute("errores", errores);
                
                RequestDispatcher rd = request.getRequestDispatcher("/nuevoCliente.jsp");
                rd.forward(request, response);
            }
        } catch (ExcepcionDeAplicacion ex) {
            Logger.getLogger(NuevoCliente.class.getName()).log(Level.SEVERE, null, ex);
            
        }
    }

    /**
     *
     * @param errores lista que tendra los errores de la comprobacion
     * @param nom nombre del usuario
     * @param pwd contraseña del usuario
     * @param pwd2 comprobacion contraseña del usuario
     *
     */
    protected void comprobarCampos(List<String> errores, String nom, String pwd, String pwd2, int priva, Cliente cl) throws ExcepcionDeAplicacion, IOException, ReCaptchaException {
        if (priva != 1) {
            errores.add("Debes aceptar las politicas de privacidad");
        }

        if (UtilesString.isVacia(nom) || nom == null
                || UtilesString.isVacia(pwd) || pwd == null
                || UtilesString.isVacia(pwd2) || pwd2 == null
                || UtilesString.isVacia(cl.getCif()) || cl.getCif() == null
                || UtilesString.isVacia(cl.getEmail()) || cl.getEmail() == null
                //error null pointer linea 113 ahora 114 posiblemente el getDireccion
                || UtilesString.isVacia(cl.getDireccion().getCalle()) || cl.getDireccion().getCalle() == null
                || UtilesString.isVacia(cl.getDireccion().getCiudad()) || cl.getDireccion().getCiudad() == null
                || UtilesString.isVacia(cl.getDireccion().getCp()) || cl.getDireccion().getCp() == null
                || UtilesString.isVacia(cl.getDireccion().getProvincia()) || cl.getDireccion().getProvincia() == null) {

            errores.add("Debes proporcionar valor para todos los campos requeridos");
        }
        
       
        // Debemos comprobar antes el nulo porque si no nos dara nullpointerexception
        if (cl.getCif()!=null && cl.getCif().length() > 50) {
            errores.add("El numero de caracteres maximo para el CIF es de 50");
        }
            
        if (cl.getDireccion().getCalle()!=null && cl.getDireccion().getCalle().length() > 50  ) {
            errores.add("El numero de caracteres maximo para la calle es de 50");
        }
        if (cl.getDireccion().getCp()!=null && cl.getDireccion().getCp().length() > 5) {
            errores.add("El numero de caracteres maximo para el codigo postal es de 5");
        }
        if (cl.getDireccion().getCiudad()!=null && cl.getDireccion().getCiudad().length() > 20 ) {
            errores.add("El numero de caracteres maximo para la ciudad es de 20");
        }
        if (cl.getDireccion().getProvincia()!=null && cl.getDireccion().getProvincia().length() > 35 ) {
            errores.add("El numero de caracteres maximo para la provincia es de 35");
        }
       
        if (cl.getEmail()!=null && cl.getEmail().length() > 100) {
            errores.add("El numero de caracteres maximo para el email es de 100");
        }
        if (nom!=null && nom.length() > 50 ) {
            errores.add("El numero de caracteres maximo para el usuario es de 50");
        }

        if (!UtilesString.isVacia(pwd2) && !UtilesString.isVacia(pwd) && !pwd2.equals(pwd)) {
            errores.add("Las contraseñas no coinciden");
        }

        if (!UtilesString.isVacia(cl.getCif()) && gbd.getClienteByCIF(cl.getCif()) != null) {
            errores.add("Existe un usario registrado con ese CIF");
        }

        if (!UtilesString.isVacia(nom) && gbd.getClienteByUserName(nom) != null) {
            errores.add("Existe un usario registrado con ese username");
        }

        if (nom!=null && nom.trim().length() != nom.length()) {
            errores.add("El nombre de usuario no puede contener espacios en blanco");
        }

        if (cl.getDireccion()!=null && !UtilesString.isVacia(cl.getDireccion().getCp()) && !Validacion.isCPValido(cl.getDireccion().getCp())) {
            errores.add("El CP introducido no es valido");
        }
        if (!UtilesString.isVacia(cl.getEmail()) && !Validacion.isEmailValido(cl.getEmail())) {
            errores.add("El email introducido no es valido");
        }

    }
}
