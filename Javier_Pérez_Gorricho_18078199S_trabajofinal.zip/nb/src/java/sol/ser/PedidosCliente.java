/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sol.ser;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import paw.bd.GestorBD;
import paw.bd.GestorBDPedidos;
import paw.model.Cliente;
import paw.model.ExcepcionDeAplicacion;
import paw.model.Pedido;
import paw.model.PedidoAnulado;

/**
 *
 * @author javie
 */
public class PedidosCliente extends HttpServlet {

    GestorBDPedidos gbdp;

    public void init() throws ServletException {
        super.init();
        gbdp = (GestorBDPedidos) this.getServletContext().getAttribute("gbdp");
        if (gbdp == null) {
            gbdp = new GestorBDPedidos();
            this.getServletContext().setAttribute("gbdp", gbdp);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            HttpSession session=request.getSession();
            Cliente cliente= (Cliente) session.getAttribute("cliente");
            if(session.getAttribute("carrito")==null){
                session.setAttribute("carrito", gbdp.getPedidoEnRealizacion(cliente.getCodigo()));
            }
            List<Pedido> pedpend=(List<Pedido>)  gbdp.getPedidosPendientes(cliente.getCodigo());
            List<Pedido> pedcomp=(List<Pedido>)  gbdp.getPedidosCompletados(cliente.getCodigo());
            List<PedidoAnulado> pedanu=(List<PedidoAnulado>) gbdp.getPedidosAnulados(cliente.getCodigo());
            
            request.setAttribute("pedpend", pedpend);
            request.setAttribute("pedcomp", pedcomp);
            request.setAttribute("pedanu", pedanu);
            
            RequestDispatcher rd= request.getRequestDispatcher("/clientes/pedidosCliente.jsp");
            rd.forward(request, response);
            
        } catch (ExcepcionDeAplicacion ex) {
            Logger.getLogger(PedidosCliente.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
