/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sol.ser;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import paw.bd.GestorBDPedidos;
import paw.model.ExcepcionDeAplicacion;
import paw.model.PedidoEnRealizacion;


public class Salir extends HttpServlet {
      GestorBDPedidos gbdp;

    public void init() throws ServletException {
        super.init();
        gbdp = (GestorBDPedidos) this.getServletContext().getAttribute("gbdp");
        if (gbdp == null) {
            gbdp = new GestorBDPedidos();
            this.getServletContext().setAttribute("gbdp", gbdp);
        }
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session =request.getSession(false);
        if (session == null) {
        response.sendRedirect("Login");
        return;
        }
        else{
            PedidoEnRealizacion carrito=(PedidoEnRealizacion) session.getAttribute("carrito");
            if(carrito!=null){
                try {
                    gbdp.grabaPedidoEnRealizacion(carrito);
                } catch (ExcepcionDeAplicacion ex) {
                    Logger.getLogger(Salir.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            session.invalidate();
            response.sendRedirect("index.html");
            return;
        }
        
        
    }

}
