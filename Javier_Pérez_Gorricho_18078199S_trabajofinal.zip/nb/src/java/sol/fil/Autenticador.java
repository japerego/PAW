/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sol.fil;

import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import paw.bd.GestorBDPedidos;
import paw.model.Cliente;
import paw.model.ExcepcionDeAplicacion;

/**
 *
 * @author javie
 */
public class Autenticador implements Filter {
    public void doFilter(ServletRequest request,ServletResponse response,FilterChain chain) throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse resp = (HttpServletResponse) response;
        HttpSession session = req.getSession();
        Cliente cliente = (Cliente) session.getAttribute("cliente");
        if (cliente == null) {
            String returnURL = req.getRequestURL()+"?"+req.getQueryString();
            /*
            if(session.getAttribute("carrito")==null){
                try {
                    GestorBDPedidos gbdp= new GestorBDPedidos();
                    session.setAttribute("carrito", gbdp.getPedidosPendientes(cliente.getCodigo()));
                } catch (ExcepcionDeAplicacion ex) {
                    Logger.getLogger(Autenticador.class.getName()).log(Level.SEVERE, null, ex);
                }
            }*/
            session.setAttribute("retorno",returnURL);
            resp.sendRedirect("../Login");
            
        } else {
            chain.doFilter(request, response);
        }
    }

    public void destroy() {
    }

    public void init(FilterConfig filterConfig) {
    }
}
