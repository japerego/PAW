/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sol.ajax;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import paw.bd.GestorBD;
import paw.model.ExcepcionDeAplicacion;
import paw.util.UtilesString;
import paw.util.Validacion;

/**
 *
 * @author javie
 */
@WebServlet(name = "GetProvinciaPorCp", urlPatterns = {"/api/GetProvinciaPorCp"})
public class GetProvinciaPorCp extends HttpServlet {

    private static GestorBD gbd = new GestorBD();


    public void init() throws ServletException {
        super.init();
        gbd = (GestorBD) this.getServletContext().getAttribute("gbd");
        if (gbd == null) {
            gbd = new GestorBD();
            this.getServletContext().setAttribute("gbd", gbd);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/plain");
        try {
            String cp = request.getParameter("codp");
            if (!UtilesString.isVacia(cp) ){
                if(Validacion.isCPValido(cp)){
                    String prov = gbd.getProvinciaDeCp(cp);
                    response.getWriter().print(prov);
                }
                else{
                    response.getWriter().print("-Elige-");
                }
            } else {
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Código de artículo no especificado ");
            }
        } catch (ExcepcionDeAplicacion ex) {
             response.sendError(HttpServletResponse.SC_NOT_FOUND, "Código de artículo no encontrado ");
        }

    }

}
