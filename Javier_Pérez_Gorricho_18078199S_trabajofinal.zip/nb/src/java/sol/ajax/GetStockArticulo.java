/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sol.ajax;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import paw.bd.GestorBD;
import paw.model.ExcepcionDeAplicacion;
import paw.util.UtilesString;
import sol.ser.BuscarArticulos;

/**
 *
 * @author javie
 */
@WebServlet(name = "GetStockArticulo", urlPatterns = {"/api/GetStockArticulo"})
public class GetStockArticulo extends HttpServlet {

    private static GestorBD gbd = new GestorBD();


    public void init() throws ServletException {
        super.init();
        gbd = (GestorBD) this.getServletContext().getAttribute("gbd");
        if (gbd == null) {
            gbd = new GestorBD();
            this.getServletContext().setAttribute("gbd", gbd);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/plain");
        try {
            int stock = 0;
            String cart = request.getParameter("cart");
            if (!UtilesString.isVacia(cart)) {
                stock = gbd.getStockArticulo(cart);
                response.getWriter().print(stock);
            } else {
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Código de artículo no especificado ");
            }
        } catch (ExcepcionDeAplicacion ex) {
             response.sendError(HttpServletResponse.SC_NOT_FOUND, "Código de artículo no encontrado ");
        }

    }

}
