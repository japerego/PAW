import "../../styles/calendar.scss";
export { tooltip } from "../../ts-message";
export { Popup } from "../../ts-popup";
export { Calendar } from "./Calendar";
export declare const i18n: any;
