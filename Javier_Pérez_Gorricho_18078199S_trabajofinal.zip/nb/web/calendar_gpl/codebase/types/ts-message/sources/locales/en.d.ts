declare const locale: {
    apply: string;
    reject: string;
};
export default locale;
