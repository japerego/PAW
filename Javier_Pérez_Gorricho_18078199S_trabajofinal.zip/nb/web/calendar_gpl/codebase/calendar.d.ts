export as namespace dhx;

export * from "./types/ts-calendar/sources/entry";
